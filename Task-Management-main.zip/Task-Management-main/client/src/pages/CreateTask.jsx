import TaskForm from "../Components/Task Form/TaskForm";

const CreateTask = () => {
  return (
    <div>
      <TaskForm />
    </div>
  );
};

export default CreateTask;
